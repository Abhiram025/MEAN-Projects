import { Component, OnInit } from '@angular/core';
import { CarService } from '../services/car.service';
import { SharedService } from '../shared.service';

interface Car {
  _id: string;
  make: string;
  model: string;
  carCategory: 'economy' | 'premier' | 'luxury';
  pricePerKm: number;
  pricePerDay: number;
  imageUrl: string;
  gearType: 'manual' | 'automatic';
  userDistance?: number;
  rentalDays?: number;
  loyaltyPoints?: number;
  extraDiscountRides?: number;
  details?: string;
}

@Component({
  selector: 'app-carlist',
  templateUrl: './carlist.component.html',
  styleUrls: ['./carlist.component.css']
})
export class CarlistComponent {

  selectedType: string = 'all';
  selectedGearType: string = 'all';
  // selectedCity: string = 'all';
  city: string = 'All';
  carname: string = '';
  car1: string = '';
  cars: any[] = [];
  isLoading: boolean = false;

  constructor(private sharedService: SharedService, public carService: CarService) { }

  ngOnInit(): void {
    const { city, carname, car1 } = this.sharedService.getCityAndCar();
    this.city = city;
    this.carname = carname;
    this.car1 = car1;

    this.loadCars()
  }

  loadCars(): void {
    this.isLoading = true;
    const observable = this.selectedType === 'all' ? this.carService.getAvailableCars() : this.carService.getCarsByType(this.selectedType);
    observable.subscribe({
      next: (cars: Car[]) => {
        this.cars = cars.map(car => ({
          ...car,
          userDistance: null,
          rentalDays: null,
          loyaltyPoints: 0,
          extraDiscountRides: 0,
          details: this.generateCarDetails(car)
        }));
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Error loading cars:', err);
        this.isLoading = false;
      }
    });
  }

  generateCarDetails(car: Car): string {
    switch (car.carCategory) {
      case 'economy':
        return 'Economical and fuel-efficient';
      case 'premier':
        return 'Comfortable and spacious';
      case 'luxury':
        return 'Luxury and high performance';
      default:
        return 'Car available for rent';
    }
  }

  // ctype = 'luxury';

  // cars: Car[] = [
  //   { name: 'Car 1', image: './assets/suv6.jfif', model: 'Model 1', type: 'economy', rentalDetails: { pricePerKm: 10, discount: 20, perDayCost: 500 }, details: 'Economical and fuel-efficient', gearType: 'manual', isFrequentRenter: true, loyaltyPoints: 0, extraDiscountRides: 0 },
  //   { name: 'Car 2', image: './assets/suv1.jfif', model: 'Model 2', type: 'premier', rentalDetails: { pricePerKm: 12, discount: 25, perDayCost: 700 }, details: 'Comfortable and spacious', gearType: 'automatic', isFrequentRenter: false, loyaltyPoints: 0, extraDiscountRides: 0 },
  //   { name: 'Car 3', image: './assets/suv2.jfif', model: 'Model 3', type: 'luxury', rentalDetails: { pricePerKm: 15, discount: 30, perDayCost: 1000 }, details: 'Luxury and high performance', gearType: 'automatic', isFrequentRenter: true, loyaltyPoints: 0, extraDiscountRides: 0 },
  //   { name: 'Car 4', image: './assets/suv3.jfif', model: 'Model 4', type: 'economy', rentalDetails: { pricePerKm: 10, discount: 20, perDayCost: 500 }, details: 'Economical and fuel-efficient', gearType: 'automatic', isFrequentRenter: true, loyaltyPoints: 0, extraDiscountRides: 0 },
  //   { name: 'Car 5', image: './assets/suv4.jfif', model: 'Model 1', type: 'premier', rentalDetails: { pricePerKm: 10, discount: 20, perDayCost: 500 }, details: 'Comfortable and spacious', gearType: 'manual', isFrequentRenter: true, loyaltyPoints: 0, extraDiscountRides: 0 },
  //   { name: 'Car 6', image: './assets/suv5.jfif', model: 'Model 3', type: 'luxury', rentalDetails: { pricePerKm: 10, discount: 20, perDayCost: 500 }, details: 'Luxury and high performance', gearType: 'manual', isFrequentRenter: true, loyaltyPoints: 0, extraDiscountRides: 0 }
  // ];

  onTypeChange(): void {
    this.loadCars();
  }

  get filteredCars(): Car[] {
    return this.cars.filter(car => (this.selectedGearType === 'all' || car.gearType === this.selectedGearType)
    );
  }

  calculateRentalCost(car: Car): number {
    if (!car.userDistance || !car.rentalDays) return 0;

    const baseCost = car.pricePerKm * car.userDistance;
    let totalCost = baseCost;

    // Add daily rental cost (excluding first day which is included in distance cost)
    if (car.rentalDays > 1) {
      totalCost += car.pricePerDay * (car.rentalDays - 1);
    }

    // Apply discounts based on category
    if (car.extraDiscountRides && car.extraDiscountRides > 0) {
      totalCost *= 0.9; // 10% discount
    }

    return totalCost;
  }

  calculateLoyaltyPoints(car: Car): void {
    if (!car.userDistance) return;

    const points = Math.floor(car.userDistance / 50);
    car.loyaltyPoints = (car.loyaltyPoints || 0) + points;

    if (car.loyaltyPoints >= 25) {
      car.extraDiscountRides = 2;
      car.loyaltyPoints -= 25;
    }
  }

  bookCar(car: Car): void {
    if (!car.userDistance || !car.rentalDays) return;

    const cost = this.calculateRentalCost(car);
    alert(`Booking confirmed for ${car.make} ${car.model}!
           Distance: ${car.userDistance} km
           Days: ${car.rentalDays}
           Total Cost: ₹${cost.toFixed(2)}
           Loyalty Points: ${car.loyaltyPoints}
           Extra Discount Rides: ${car.extraDiscountRides || 0}`
          );
  }
}