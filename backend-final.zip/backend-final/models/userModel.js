const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
   email: { 
    type: String, 
    required: true, 
    unique: true,
    validate: {
      validator: function(v) {
        // Regex for basic email validation
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
      },
      message: props => `${props.value} is not a valid email address!`
    }
  },
  password: { type: String, required: true },
  role: { type: String, enum: ['user', 'admin'], default: 'user' },
  profile: {
    firstName: { 
    type: String, 
    required: true, 
    unique: true // Only if names must be unique
  },
    lastName: String,
    phone: String,
    address: {
      type: String, 
      required: true, 
      unique: true
    }
  },
  loyaltyPoints: { type: Number, default: 0 },
  eligibleForDiscountedRides: { type: Number, default: 0 },
  resetPasswordToken: String,
  resetPasswordExpires: Date
}, { timestamps: true });

userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 10);
  next();
});

userSchema.methods.comparePassword = async function(candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

module.exports = mongoose.model('User', userSchema);