const mongoose = require('mongoose');

const taxSchema = new mongoose.Schema({
   cartype: { 
    type: String, 
    enum: ['sedan', 'suv', 'hyundai', 'honda', 'force'], // Updated to match your requirements
    required: true,
    unique: true
  },
  taxPercentage: { type: Number, required: true },
  taxCategory: {  // New field to match your categories
    type: String,
    enum: ['economy', 'premier', 'luxury'],
    required: true
  }
});

module.exports = mongoose.model('Tax', taxSchema);