const TaxService = require('../services/taxService');

class TaxController {
  async createTaxRule(req, res) {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Forbidden' });
      }
      const taxRule = await TaxService.createTaxRule(req.body);
      res.status(201).json(taxRule);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  async updateTaxRule(req, res) {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Forbidden' });
      }
      const taxRule = await TaxService.updateTaxRule(req.params.carType, req.body.taxPercentage);
      res.json(taxRule);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  async getTaxByCarType(req, res) {
    try {
      const taxRule = await TaxService.getTaxByCarType(req.params.carType);
      res.json(taxRule);
    } catch (error) {
      res.status(404).json({ message: error.message });
    }
  }

  async getAllTaxRules(req, res) {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Forbidden' });
      }
      const taxRules = await TaxService.getAllTaxRules();
      res.json(taxRules);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }
}

module.exports = new TaxController();