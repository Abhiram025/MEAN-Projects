const UserService = require('../services/userService');

class UserController {
  async getProfile(req, res) {
    try {
      const user = await UserService.getUserById(req.user.id);
      res.json(user);
    } catch (error) {
      res.status(404).json({ message: error.message });
    }
  }

  async updateProfile(req, res) {
    try {
      const user = await UserService.updateProfile(req.user.id, req.body);
      res.json(user);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  async changePassword(req, res) {
    try {
      const { currentPassword, newPassword } = req.body;
      if (!currentPassword || !newPassword) {
        return res.status(400).json({ message: 'Both current and new password are required' });
      }
      await UserService.changePassword(req.user.id, currentPassword, newPassword);
      res.json({ message: 'Password changed successfully' });
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  async resetPassword(req, res) {
    try {
      const {email, newPassword, confirmPassword}=req.body;
      if(!email || !newPassword || !confirmPassword) {
        return res.status(400).json({ message: 'All fields are required' });
      }
      await UserService.resetPassword(req.user?.id, email, newPassword, confirmPassword);
      res.status(200).json({message: 'Password Reset is Successful'});
    } catch(err) {
      console.log("Password reset error: ", err.message);
      const statusCode=err.message.includes('not found')?404:400;
      res.status(statusCode).json({
        message:err.message || 'Password reset failed'
      });
    }
  }
}

module.exports = new UserController();