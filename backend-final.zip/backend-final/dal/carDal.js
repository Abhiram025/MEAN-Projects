const BaseDAL = require('./baseDal');
const Car = require('../models/carModel');

class CarDAL extends BaseDAL {
  constructor() {
    super(Car);
  }

  async findAvailableCars() {
    return await this.find({ availabilityStatus: 'available' });
  }

  async findByType(carType) {
    return await this.find({ type: carType, availabilityStatus: 'available' });
  }
}

module.exports = new CarDAL();