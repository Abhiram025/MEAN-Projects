const UserDAL = require('../dal/userDal');

class UserService {
  async updateProfile(userId, profileData) {
    return await UserDAL.updateById(userId, profileData);
  }

  async changePassword(userId, currentPassword, newPassword) {
    const user = await UserDAL.findById(userId);
    const isMatch = await user.comparePassword(currentPassword);
    if (!isMatch) {
      throw new Error('Current password is incorrect');
    }

    if (newPassword.length < 8) {
      throw new Error('Password must be at least 8 characters');
    }

    // Hash and save new password
    user.password = newPassword;
    await user.save(); // This triggers the pre-save hook
    
    return user;
  }

  async resetPassword(userId, email, newPassword, confirmPassword) {
    const user = userId ? UserDAL.findById(userId):UserDAL.findByEmail(email);
    if(!user) throw new Error("User not found")
    
    if(newPassword!==confirmPassword) throw new Error("Passwords don't match")    
    if(newPassword.length<8) throw new Error('Password must be atleast 8 characters')
    
    const samePassword=await user.checkPassword(newPassword);//problem
    if(samePassword) throw new Error("Cannot use previous password") 

    user.password=newPassword;
    await user.save();
    return user;
  }

  async getUserById(userId) {
    return await UserDAL.findById(userId);
  }
}

module.exports = new UserService();