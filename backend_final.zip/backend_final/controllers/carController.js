const CarService = require('../services/carService');

class CarController {
  async createCar(req, res) {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Forbidden' });
      }
      // if (!req.body.registrationNumber) {
      //   return res.status(400).json({ message: 'Registration number is required' });
      // }
      const car = await CarService.createCar(req.body);
      res.status(201).json(car);
    } catch (error) {
      console.log("you are not admin")
      res.status(400).json({ message: error.message });
    }
  }

  async updateCar(req, res) {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Forbidden' });
      }
      const car = await CarService.updateCar(req.params.id, req.body);
      res.json(car);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  async deleteCar(req, res) {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Forbidden' });
      }
      await CarService.deleteCar(req.params.id);
      res.json({ message: 'Car deleted successfully' });
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  async getAvailableCars(req, res) {
    try {
      const cars = await CarService.getAvailableCars();
      res.json(cars);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  async getCarsByType(req, res) {
    try {
      const cars = await CarService.getCarsByType(req.params.type);
      res.json(cars);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  async getCarById(req, res) {
    try {
      const car = await CarService.getCarById(req.params.id);
      res.json(car);
    } catch (error) {
      res.status(404).json({ message: error.message });
    }
  }
}

module.exports = new CarController();