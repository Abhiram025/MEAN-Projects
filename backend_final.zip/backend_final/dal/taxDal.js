const BaseDAL = require('./baseDal');
const Tax = require('../models/taxModel');

class TaxDAL extends BaseDAL {
  constructor() {
    super(Tax);
  }

  async findByCarType(carType) {
    return await this.findOne({ carType });
  }
}

module.exports = new TaxDAL();