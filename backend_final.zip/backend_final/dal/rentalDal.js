const BaseDAL = require('./baseDal');
const Rental = require('../models/rentalModel');

class RentalDAL extends BaseDAL {
  constructor() {
    super(Rental);
  }

  async findUserRentals(userId, status) {
    const query = { user: userId };
    if (status) {
      if (status === 'previous') {
        query.status = 'completed';
      } else if (status === 'future') {
        query.status = { $in: ['booked', 'rented'] };
      }
    }
    return await this.find(query).populate('car');
  }

  async findAllRentals() {
    return await this.find().populate('user car');
  }
}

module.exports = new RentalDAL();