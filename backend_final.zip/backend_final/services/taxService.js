const TaxDAL = require('../dal/taxDal');

class TaxService {
  async createTaxRule(taxData) {
    return await TaxDAL.create(taxData);
  }

  async updateTaxRule(carType, taxPercentage) {
    return await TaxDAL.updateById(carType, { taxPercentage });
  }

  async getTaxByCarType(carType) {
    return await TaxDAL.findByCarType(carType);
  }

  async getAllTaxRules() {
    return await TaxDAL.find();
  }

  getCarTypeTaxCategory(carType) {
    // Simple mapping of car types to tax categories
    const taxCategories = {
      compact: 'basic',
      sedan: 'basic',
      suv: 'mid-range',
      minivan: 'mid-range',
      luxury: 'luxury'
    };
    return taxCategories[carType] || 'basic';
  }
}

module.exports = new TaxService();