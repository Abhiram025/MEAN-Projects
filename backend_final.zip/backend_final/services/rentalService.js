const RentalDAL = require('../dal/rentalDal');
const CarDAL = require('../dal/carDal');
const UserDAL = require('../dal/userDal');
const TaxService = require('./taxService');

const KM_FOR_LOYALTY_POINT = 50;
const POINTS_FOR_DISCOUNT_RIDES = 25;
const DISCOUNTED_RIDES_COUNT = 2;
const FREQUENT_RENTER_KM_THRESHOLD = 1000;
const FREQUENT_RENTER_DISCOUNT_RATE = 0.10;
const LOYALTY_RIDE_DISCOUNT_FIXED_AMOUNT = 20;

class RentalService {
  async bookCar(userId, carId, rentalStartDate, rentalEndDate) {
    const [car, user] = await Promise.all([
      CarDAL.findById(carId),
      UserDAL.findById(userId),
      console.log("user id is: ", userId)
    ]);
    
    if (!car || car.availabilityStatus !== 'available') {
      throw new Error('Car not available for booking');
    }
    if (!user) throw new Error('User not found');

    const taxRule = await TaxService.getTaxByCarType(car.type);
    if (!taxRule) throw new Error('Tax rule not found for car type');

    return await RentalDAL.create({
      user: userId,
      car: carId,
      rentalStartDate,
      rentalEndDate,
      baseCostPerKm: car.pricePerKm,
      baseCostPerDay: car.pricePerDay,
      taxRateApplied: taxRule.taxPercentage / 100,
      status: 'booked'
    });
  }

  async pickupCar(rentalId, pickupOdometerReading) {
    const rental = await RentalDAL.findById(rentalId);
    if (!rental || rental.status !== 'booked') {
      throw new Error('Invalid rental for pickup');
    }

    const car = await CarDAL.findById(rental.car);
    if (!car || pickupOdometerReading < car.currentOdometer) {
      throw new Error('Invalid odometer reading');
    }

    await CarDAL.updateById(rental.car, {
      availabilityStatus: 'rented',
      currentOdometer: pickupOdometerReading
    });

    return await RentalDAL.updateById(rentalId, {
      actualPickupDate: new Date(),
      pickupOdometer: pickupOdometerReading,
      status: 'rented'
    });
  }

  async returnCar(rentalId, returnOdometerReading) {
    const rental = await RentalDAL.findById(rentalId).populate('user car');
    if (!rental || rental.status !== 'rented') {
      throw new Error('Invalid rental for return');
    }
    if (!rental.pickupOdometer || returnOdometerReading < rental.pickupOdometer) {
      throw new Error('Invalid odometer reading');
    }

    const totalKmDriven = returnOdometerReading - rental.pickupOdometer;
    const durationDays = Math.ceil((new Date() - rental.actualPickupDate) / (1000 * 60 * 60 * 24));
    
    let calculatedCost = durationDays * rental.baseCostPerDay + totalKmDriven * rental.baseCostPerKm;
    const taxAmount = calculatedCost * rental.taxRateApplied;
    let finalCost = calculatedCost + taxAmount;

    // Apply frequent renter discount
    const pastRentals = await RentalDAL.find({ user: rental.user._id, status: 'completed' });
    const totalUserKmRented = pastRentals.reduce((sum, r) => sum + (r.totalKmDriven || 0), 0);

    if ((totalUserKmRented + totalKmDriven) > FREQUENT_RENTER_KM_THRESHOLD) {
      finalCost -= finalCost * FREQUENT_RENTER_DISCOUNT_RATE;
    }

    // Apply loyalty discount if available
    if (rental.user.eligibleForDiscountedRides > 0) {
      finalCost -= LOYALTY_RIDE_DISCOUNT_FIXED_AMOUNT;
      rental.user.eligibleForDiscountedRides -= 1;
    }
    finalCost = Math.max(0, finalCost);

    // Update loyalty points
    const loyaltyPointsEarned = Math.floor(totalKmDriven / KM_FOR_LOYALTY_POINT);
    rental.user.loyaltyPoints += loyaltyPointsEarned;

    if (rental.user.loyaltyPoints >= POINTS_FOR_DISCOUNT_RIDES) {
      const setsOfPoints = Math.floor(rental.user.loyaltyPoints / POINTS_FOR_DISCOUNT_RIDES);
      rental.user.eligibleForDiscountedRides += setsOfPoints * DISCOUNTED_RIDES_COUNT;
      rental.user.loyaltyPoints %= POINTS_FOR_DISCOUNT_RIDES;
    }

    await UserDAL.updateById(rental.user._id, {
      loyaltyPoints: rental.user.loyaltyPoints,
      eligibleForDiscountedRides: rental.user.eligibleForDiscountedRides
    });

    await CarDAL.updateById(rental.car._id, {
      availabilityStatus: 'available',
      currentOdometer: returnOdometerReading
    });

    return await RentalDAL.updateById(rentalId, {
      actualReturnDate: new Date(),
      returnOdometer: returnOdometerReading,
      totalKmDriven,
      taxAmount,
      totalCost: finalCost,
      status: 'completed',
      loyaltyPointsEarned
    });
  }

  async cancelBooking(rentalId, userId, isAdmin = false) {
    const rental = await RentalDAL.findById(rentalId).populate('user');
    if (!rental) throw new Error('Rental not found');
    if (!isAdmin && rental.user._id.toString() !== userId.toString()) {
      throw new Error('Not authorized to cancel this booking');
    }
    if (rental.status !== 'booked') throw new Error('Cannot cancel booking');

    return await RentalDAL.updateById(rentalId, { status: 'cancelled' });
  }

  async getUserRentals(userId, type = 'all') {
    return await RentalDAL.findUserRentals(userId, type);
  }

  async getAllRentals() {
    return await RentalDAL.findAllRentals();
  }
}

module.exports = new RentalService();