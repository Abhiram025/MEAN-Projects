const UserDAL = require('../dal/userDal');

class UserService {
  async updateProfile(userId, profileData) {
    return await UserDAL.updateById(userId, { profile: profileData });
  }

  async changePassword(userId, newPassword) {
    return await UserDAL.updateById(userId, { password: newPassword });
  }

  async getUserById(userId) {
    return await UserDAL.findById(userId);
  }
}

module.exports = new UserService();