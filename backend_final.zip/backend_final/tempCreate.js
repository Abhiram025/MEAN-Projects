const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const config = require('./config');

async function createUser() {
  try {
    await mongoose.connect(config.MONGODB_URI);

    const hashedPassword = await bcrypt.hash("12345678901", 10);

    const user = await mongoose.connection.db.collection('users').insertOne({
      username: "Abhiram25",
      firstname: "Abhiram",
      lastname: "Abhi",
      address: "Pune, Maharashtra",
      email: "abhi05@gmail.com",
      password: hashedPassword,
      role: "admin",
    });

    console.log("User created successfully:", user);
    process.exit(0);
  } catch (error) {
    console.error("Error:", error);
    process.exit(1);
  }
}

createUser();