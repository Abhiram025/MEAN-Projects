const mongoose = require('mongoose');
const User = require('./userModel');
const Car=require('./carModel')
const rentalSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  car: { type: mongoose.Schema.Types.ObjectId, ref: 'Car', required: true },
  rentalStartDate: { type: Date, required: true },
  rentalEndDate: { type: Date, required: true },
  actualPickupDate: Date,
  actualReturnDate: Date,
  pickupOdometer: Number,
  returnOdometer: Number,
  totalKmDriven: Number,
  baseCostPerKm: Number,
  baseCostPerDay: Number,
  taxRateApplied: Number,
  taxAmount: Number,
  frequentRenterDiscountAmount: Number,
  loyaltyDiscountAmount: Number,
  totalCost: Number,
  status: { 
    type: String, 
    enum: ['booked', 'rented', 'completed', 'cancelled'], 
    default: 'booked' 
  },
  loyaltyPointsEarned: { type: Number, default: 0 }
}, { timestamps: true });

module.exports = mongoose.model('Rental', rentalSchema);