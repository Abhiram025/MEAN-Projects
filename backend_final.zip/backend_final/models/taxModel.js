const mongoose = require('mongoose');

const taxSchema = new mongoose.Schema({
  carType: { 
    type: String, 
    enum: ['compact', 'sedan', 'suv', 'minivan', 'luxury'],
    required: true,
    unique: true
  },
  taxPercentage: { type: Number, required: true }
});

module.exports = mongoose.model('Tax', taxSchema);