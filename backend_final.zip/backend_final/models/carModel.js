const mongoose = require('mongoose');

const carSchema = new mongoose.Schema({
  make: { type: String, required: true },
  model: { type: String, required: true },
  cartype: { 
    type: String, 
    required: true,
    enum: ['hyundai-i20', 'sedan', 'suv', 'force traveller', 'honda city'] 
  },
  carCategory: { 
    type: String, 
    required: true,
    enum: ['economy', 'premier', 'luxury'] 
  },
  year: { type: Number, required: true },
  pricePerKm: { type: Number, required: true },
  pricePerDay: { type: Number, required: true },
  availabilityStatus: { 
    type: String, 
    enum: ['available', 'rented', 'maintenance'], 
    default: 'available' 
  },
  currentOdometer: { type: Number, required: true },
  imageUrl: String,
  features: [String]
}, { timestamps: true });

module.exports = mongoose.model('Car', carSchema);