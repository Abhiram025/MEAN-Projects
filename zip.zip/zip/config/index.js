const dotenv = require('dotenv');
dotenv.config(); // Load environment variables from .env file

module.exports = {
    port: process.env.PORT || 5001,
    mongoURI: process.env.MONGO_URI,
    jwtSecret: process.env.JWT_SECRET,
    jwtExpiresIn: process.env.JWT_EXPIRES_IN,
};