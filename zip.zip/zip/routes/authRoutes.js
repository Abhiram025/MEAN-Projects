const express = require('express');
const router = express.Router();
const { registerUser, loginUser, logoutUser, createAdmin, forgotPassword, resetPassword } = require('../controllers/authController');
const { protect, authorize } = require('../middleware/authMiddleware');

router.post('/register', registerUser);
router.post('/login', loginUser);
router.post('/logout', protect, logoutUser); // Logout can be protected if it does server-side invalidation (not typical for pure JWT)
router.post('/forgot-password', forgotPassword);
router.put('/reset-password/:token', resetPassword);

// Admin specific auth route
router.post('/admin/create-admin', protect, authorize('admin'), createAdmin);


module.exports = router;