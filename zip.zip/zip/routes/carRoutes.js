const express = require('express');
const router = express.Router();
const {
    addCar,
    getAllCarsAdmin,
    getCarByIdAdmin,
    updateCar,
    deleteCar,
    searchCars,
    getCarDetailsForUser
} = require('../controllers/carController');
const { protect, authorize } = require('../middleware/authMiddleware');

// Admin Car Routes
router.route('/admin/cars')
    .post(protect, authorize('admin'), addCar)
    .get(protect, authorize('admin'), getAllCarsAdmin);

router.route('/admin/cars/:id')
    .get(protect, authorize('admin'), getCarByIdAdmin)
    .put(protect, authorize('admin'), updateCar)
    .delete(protect, authorize('admin'), deleteCar);

// User Car Routes
router.get('/cars/search', searchCars); // Can be public or protect if only logged-in users can search
router.get('/cars/:id', getCarDetailsForUser); // Can be public or protect

module.exports = router;