const express = require('express');
const router = express.Router();
const { addTax, getAllTaxes, getTaxById, updateTax, deleteTax } = require('../controllers/taxController');
const { protect, authorize } = require('../middleware/authMiddleware');

router.route('/admin/taxes')
    .post(protect, authorize('admin'), addTax)
    .get(protect, authorize('admin'), getAllTaxes);

router.route('/admin/taxes/:id')
    .get(protect, authorize('admin'), getTaxById)
    .put(protect, authorize('admin'), updateTax)
    .delete(protect, authorize('admin'), deleteTax);

module.exports = router;