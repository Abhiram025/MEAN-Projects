const express = require('express');
const router = express.Router();
const {
    bookCar,
    getMyRentals,
    getMyRentalHistory,
    cancelBooking,
    getAllRentalsAdmin,
    getUserRentalHistoryAdmin,
    pickupCar,
    returnCar
} = require('../controllers/rentalController');
const { protect, authorize } = require('../middleware/authMiddleware');

// User Rental Routes
router.post('/rentals/book', protect, authorize('user', 'admin'), bookCar); // Admin could book for a user
router.get('/rentals/my-rentals', protect, authorize('user'), getMyRentals);
router.get('/rentals/my-history', protect, authorize('user'), getMyRentalHistory);
router.put('/rentals/:rentalId/cancel', protect, authorize('user', 'admin'), cancelBooking);

// Admin Rental Routes
router.get('/admin/rentals', protect, authorize('admin'), getAllRentalsAdmin);
router.get('/admin/rentals/user/:userId', protect, authorize('admin'), getUserRentalHistoryAdmin);
router.put('/admin/rentals/:rentalId/pickup', protect, authorize('admin'), pickupCar);
router.put('/admin/rentals/:rentalId/return', protect, authorize('admin'), returnCar);

module.exports = router;