const RentalDAL = require('../dal/rentalDal');
const CarDAL = require('../dal/carDal');
const UserDAL = require('../dal/userDal');
const TaxDAL = require('../dal/taxDal');
const TaxService = require('./taxService'); // To use getCarTypeTaxCategory

const KM_FOR_LOYALTY_POINT = 50;
const POINTS_FOR_DISCOUNT_RIDES = 25;
const DISCOUNTED_RIDES_COUNT = 2;
const FREQUENT_RENTER_KM_THRESHOLD = 1000; // Example threshold
const FREQUENT_RENTER_DISCOUNT_RATE = 0.10; // 10%
const LOYALTY_RIDE_DISCOUNT_FIXED_AMOUNT = 20; // Example: $20 off, or make it a percentage

const bookCar = async (userId, carId, rentalStartDate, rentalEndDate) => {
    const car = await CarDAL.findCarById(carId);
    if (!car) {
        const error = new Error('Car not found');
        error.statusCode = 404;
        throw error;
    }
    if (car.availabilityStatus !== 'Available') {
        const error = new Error('Car is not available for booking');
        error.statusCode = 400;
        throw error;
    }

    const user = await UserDAL.findUserById(userId);
    if (!user) {
        const error = new Error('User not found');
        error.statusCode = 404;
        throw error;
    }

    // Determine tax rate based on car type
    const carTypeTaxCategory = TaxService.getCarTypeTaxCategory(car.type);
    const taxRule = await TaxDAL.findTaxByCarTypeCategory(carTypeTaxCategory);
    if (!taxRule) {
        // Fallback or error if no tax rule defined for this car category
        console.warn(`No tax rule found for car type category: ${carTypeTaxCategory}. Using default 0% tax.`);
        // Potentially throw an error or apply a default, based on business rules.
        // For now, let's assume a critical setup error if tax isn't found.
        const error = new Error(`Tax configuration missing for car category: ${carTypeTaxCategory}`);
        error.statusCode = 500; // Server configuration error
        throw error;
    }
    const taxRateToApply = taxRule.taxPercentage / 100; // Convert percentage to decimal

    const rentalData = {
        userId,
        carId,
        rentalStartDate,
        rentalEndDate,
        baseCostPerKm: car.pricePerKm,
        baseCostPerDay: car.pricePerDay,
        taxRateApplied: taxRateToApply,
        status: 'Booked'
    };

    const rental = await RentalDAL.createRental(rentalData);
    // Optionally, mark car as 'Booked' or similar if you have such a status,
    // or rely on the 'Rented' status upon pickup. For simplicity, we update to 'Rented' on pickup.
    // await CarDAL.updateCar(carId, { availabilityStatus: 'Rented' }); // Or 'Booked' if you have it

    return rental;
};

const pickupCar = async (rentalId, pickupOdometerReading, adminUserId) => {
    // Ensure admin is performing this
    const rental = await RentalDAL.findRentalById(rentalId);
    if (!rental) {
        const error = new Error('Rental not found');
        error.statusCode = 404;
        throw error;
    }
    if (rental.status !== 'Booked') {
        const error = new Error(`Rental cannot be picked up. Status: ${rental.status}`);
        error.statusCode = 400;
        throw error;
    }

    const car = await CarDAL.findCarById(rental.carId);
    if (!car) { // Should not happen if DB is consistent
        const error = new Error('Associated car not found for rental.');
        error.statusCode = 500;
        throw error;
    }

    if (pickupOdometerReading < car.currentOdometer) {
        const error = new Error('Pickup Odometer reading cannot be less than current car odometer.');
        error.statusCode = 400;
        throw error;
    }

    const updatedRental = await RentalDAL.updateRental(rentalId, {
        actualPickupDate: new Date(),
        pickupOdometer: pickupOdometerReading,
        status: 'Rented'
    });

    await CarDAL.updateCar(rental.carId, {
        availabilityStatus: 'Rented',
        currentOdometer: pickupOdometerReading // Update car's current ODO
    });
    return updatedRental;
};

const returnCar = async (rentalId, returnOdometerReading, adminUserId) => {
    // Ensure admin is performing this
    const rental = await RentalDAL.findRentalById(rentalId); // Populate carId and userId
    if (!rental) {
        const error = new Error('Rental not found');
        error.statusCode = 404;
        throw error;
    }
    if (rental.status !== 'Rented') {
        const error = new Error(`Car cannot be returned. Status: ${rental.status}`);
        error.statusCode = 400;
        throw error;
    }
    if (!rental.pickupOdometer) {
        const error = new Error('Pickup Odometer reading missing for this rental.');
        error.statusCode = 400; // Or 500 for data integrity issue
        throw error;
    }
    if (returnOdometerReading < rental.pickupOdometer) {
        const error = new Error('Return Odometer reading cannot be less than pickup odometer.');
        error.statusCode = 400;
        throw error;
    }

    const car = rental.carId; // Already populated
    const user = rental.userId; // Already populated

    const totalKmDriven = returnOdometerReading - rental.pickupOdometer;

    // Calculate rental duration in days
    const pickupTime = new Date(rental.actualPickupDate).getTime();
    const returnTime = new Date().getTime(); // Current time for return
    const durationMs = returnTime - pickupTime;
    const durationDays = Math.ceil(durationMs / (1000 * 60 * 60 * 24)); // Round up to nearest full day

    // ---- COST CALCULATION ----
    let calculatedCost = 0;
    if (durationDays > 0) {
        calculatedCost += durationDays * rental.baseCostPerDay;
    }
    calculatedCost += totalKmDriven * rental.baseCostPerKm;

    const taxAmount = calculatedCost * rental.taxRateApplied;
    let finalCost = calculatedCost + taxAmount;

    // ---- DISCOUNTS ----
    let frequentRenterDiscountAmount = 0;
    // Check for frequent renter: total KMs rented previously + current KMs
    // This requires summing up KMs from user's past 'Completed' rentals
    const pastRentals = await RentalDAL.findRentalsByUserId(user._id);
    let totalUserKmRented = pastRentals
        .filter(r => r.status === 'Completed' && r._id.toString() !== rentalId.toString()) // Exclude current rental from past sum
        .reduce((sum, r) => sum + (r.totalKmDriven || 0), 0);

    if ((totalUserKmRented + totalKmDriven) > FREQUENT_RENTER_KM_THRESHOLD) {
        frequentRenterDiscountAmount = (calculatedCost + taxAmount) * FREQUENT_RENTER_DISCOUNT_RATE; // Apply discount on cost + tax
        finalCost -= frequentRenterDiscountAmount;
    }

    let loyaltyDiscountAmount = 0;
    if (user.eligibleForDiscountedRides > 0) {
        loyaltyDiscountAmount = LOYALTY_RIDE_DISCOUNT_FIXED_AMOUNT; // Or a percentage
        finalCost -= loyaltyDiscountAmount;
        user.eligibleForDiscountedRides -= 1;
    }
    finalCost = Math.max(0, finalCost); // Cost cannot be negative

    // ---- LOYALTY POINTS ----
    const loyaltyPointsEarned = Math.floor(totalKmDriven / KM_FOR_LOYALTY_POINT);
    user.loyaltyPoints += loyaltyPointsEarned;

    if (user.loyaltyPoints >= POINTS_FOR_DISCOUNT_RIDES) {
        const setsOfPoints = Math.floor(user.loyaltyPoints / POINTS_FOR_DISCOUNT_RIDES);
        user.eligibleForDiscountedRides += setsOfPoints * DISCOUNTED_RIDES_COUNT;
        user.loyaltyPoints = user.loyaltyPoints % POINTS_FOR_DISCOUNT_RIDES; // Remaining points
    }

    await UserDAL.updateUser(user._id, {
        loyaltyPoints: user.loyaltyPoints,
        eligibleForDiscountedRides: user.eligibleForDiscountedRides
    });

    const updatedRental = await RentalDAL.updateRental(rentalId, {
        actualReturnDate: new Date(),
        returnOdometer: returnOdometerReading,
        totalKmDriven,
        taxAmount,
        frequentRenterDiscountAmount,
        loyaltyDiscountAmount,
        totalCost: finalCost,
        status: 'Completed',
        loyaltyPointsEarned
    });

    await CarDAL.updateCar(car._id, {
        availabilityStatus: 'Available',
        currentOdometer: returnOdometerReading
    });

    return updatedRental;
};

const cancelBooking = async (rentalId, userId, userRole) => {
    const rental = await RentalDAL.findRentalById(rentalId);
    if (!rental) {
        const error = new Error('Rental booking not found');
        error.statusCode = 404;
        throw error;
    }

    // User can only cancel their own booking, Admin can cancel any
    if (userRole !== 'admin' && rental.userId._id.toString() !== userId.toString()) {
        const error = new Error('Not authorized to cancel this booking');
        error.statusCode = 403;
        throw error;
    }

    if (rental.status !== 'Booked') {
        const error = new Error(`Cannot cancel booking. Status: ${rental.status}`);
        error.statusCode = 400;
        throw error;
    }
    // Add logic for cancellation policies (e.g., time before pickup) if needed

    // No need to change car status if it was never 'Rented'
    // If you marked car as 'Booked', revert it here.
    // For now, assuming car status changes only on pickup/return.

    return await RentalDAL.updateRental(rentalId, { status: 'Cancelled' });
};

const getUserRentals = async (userId, type = 'all') => { // type can be 'previous', 'future'
    let query = { userId };
    const now = new Date();
    if (type === 'previous') {
        query.status = 'Completed'; // Or include 'Cancelled'
        // query.rentalEndDate = { $lt: now };
    } else if (type === 'future') {
        query.status = { $in: ['Booked', 'Rented'] };
        // query.rentalStartDate = { $gte: now };
    }
    // 'all' just uses userId

    return await RentalDAL.findRentalsByUserId(userId, query); // Modify DAL if query obj is passed
};

const getAllRentalsForAdmin = async () => {
    return await RentalDAL.findAllRentals();
};

const getRentalHistoryForUserByAdmin = async (userId) => {
    return await RentalDAL.findRentalsByUserId(userId); // All statuses for a specific user
};

module.exports = {
    bookCar,
    pickupCar,
    returnCar,
    cancelBooking,
    getUserRentals,
    getAllRentalsForAdmin,
    getRentalHistoryForUserByAdmin
}