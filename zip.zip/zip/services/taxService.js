const TaxDAL = require('../dal/taxDal');

const addTaxRule = async (taxData) => {
    const existingTax = await TaxDAL.findTaxByCarTypeCategory(taxData.carTypeCategory);
    if (existingTax) {
        const error = new Error(`Tax rule for '${taxData.carTypeCategory}' already exists.`);
        error.statusCode = 400;
        throw error;
    }
    return await TaxDAL.createTax(taxData);
};

const getAllTaxRules = async () => {
    return await TaxDAL.findAllTaxes();
};

const getTaxRuleById = async (taxId) => {
    const tax = await TaxDAL.findTaxById(taxId);
    if (!tax) {
        const error = new Error('Tax rule not found');
        error.statusCode = 404;
        throw error;
    }
    return tax;
};

const updateTaxRule = async (taxId, updateData) => {
    const tax = await TaxDAL.updateTax(taxId, updateData);
    if (!tax) {
        const error = new Error('Tax rule not found');
        error.statusCode = 404;
        throw error;
    }
    return tax;
};

const deleteTaxRule = async (taxId) => {
    const tax = await TaxDAL.deleteTax(taxId);
    if (!tax) {
        const error = new Error('Tax rule not found');
        error.statusCode = 404;
        throw error;
    }
    return { message: 'Tax rule deleted successfully' };
};

// Helper to map car.type to tax.carTypeCategory
const getCarTypeTaxCategory = (carType) => {
    // This mapping logic is crucial and needs to align with your Car.type and Tax.carTypeCategory enums
    // Example:
    if (['SUV', 'Luxury', 'High-end'].includes(carType)) return 'High-end/Luxury';
    if (['Sedan', 'Mini-van', 'Mid-range'].includes(carType)) return 'Mid-range';
    if (['Compact', 'Basic'].includes(carType)) return 'Basic';
    return 'Basic'; // Default or throw error if unmapped
};

module.exports = {
    addTaxRule,
    getAllTaxRules,
    getTaxRuleById,
    updateTaxRule,
    deleteTaxRule,
    getCarTypeTaxCategory
}