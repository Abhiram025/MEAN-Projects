const CarDAL = require('../dal/carDal');

const addCar = async (carData) => {
    // Add any business validation specific to adding a car
    return await CarDAL.createCar(carData);
};

const getCarById = async (carId) => {
    const car = await CarDAL.findCarById(carId);
    if (!car) {
        const error = new Error('Car not found');
        error.statusCode = 404;
        throw error;
    }
    return car;
};

const getAllCarsForAdmin = async (filters) => {
    return await CarDAL.findAllCars(filters); // Admin might see all, including 'Maintenance'
};

const searchAvailableCars = async (searchParams) => {
    const filters = { availabilityStatus: 'Available' };
    if (searchParams.type) filters.type = searchParams.type;
    if (searchParams.make) filters.make = new RegExp(searchParams.make, 'i'); // Case-insensitive search
    if (searchParams.model) filters.model = new RegExp(searchParams.model, 'i');
    // Add more filters as needed (seats, transmission, etc.)
    return await CarDAL.findAllCars(filters);
};

const updateCarDetails = async (carId, updateData) => {
    const car = await CarDAL.updateCar(carId, updateData);
    if (!car) {
        const error = new Error('Car not found');
        error.statusCode = 404;
        throw error;
    }
    return car;
};

const removeCar = async (carId) => {
    const car = await CarDAL.deleteCar(carId);
    if (!car) {
        const error = new Error('Car not found');
        error.statusCode = 404;
        throw error;
    }
    return { message: 'Car removed successfully' };
};

module.exports = {
    addCar,
    getCarById,
    getAllCarsForAdmin,
    searchAvailableCars,
    updateCarDetails,
    removeCar
}