const UserDAL = require('../dal/userDal');
const bcrypt = require('bcryptjs');

const getUserProfile = async (userId) => {
    const user = await UserDAL.findUserById(userId);
    if (!user) {
        const error = new Error('User not found');
        error.statusCode = 404;
        throw error;
    }
    return user;
};

const updateUserProfile = async (userId, updateData) => {
    // Prevent password update through this route
    if (updateData.password) {
        delete updateData.password;
    }
    // Prevent role change by non-admins
    if (updateData.role) {
        const currentUser = await UserDAL.findUserById(userId); // Fetch to check current role if needed for complex logic
        // For now, assume only admins can change roles or it's handled by a separate admin endpoint
        // To be safe, let's restrict role changes here unless an admin is doing it.
        // This would typically be handled by role-based access on the route/controller for updating other users.
        // For self-update, role should not be changeable.
        delete updateData.role;
    }

    const user = await UserDAL.updateUser(userId, updateData);
    if (!user) {
        const error = new Error('User not found');
        error.statusCode = 404;
        throw error;
    }
    return user;
};

const changePassword = async (userId, oldPassword, newPassword) => {
    const user = await User.findById(userId); // Need full user object for matchPassword
    if (!user) {
        const error = new Error('User not found');
        error.statusCode = 404;
        throw error;
    }

    if (!(await user.matchPassword(oldPassword))) {
        const error = new Error('Incorrect old password');
        error.statusCode = 401;
        throw error;
    }

    user.password = newPassword; // Pre-save hook will hash
    await user.save();
    return { message: 'Password changed successfully' };
};

module.exports = {
    getUserProfile,
    updateUserProfile,
    changePassword
}