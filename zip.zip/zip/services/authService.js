const UserDAL = require('../dal/userDal');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const crypto = require('crypto'); // For reset token
const config = require('../config');
// const sendEmail = require('../utils/sendEmail'); // You'd need to implement an email utility

const generateToken = (id) => {
    return jwt.sign({ id }, config.jwtSecret, {
        expiresIn: config.jwtExpiresIn,
    });
};

const registerUser = async (userData) => {
    try {
        const { email, password } = userData;
        const userExists = await UserDAL.findUserByEmail(email);
        if (userExists) {
            const error = new Error('User already exists');
            error.statusCode = 400;
            throw error;
        }
        // Add CAPTCHA server-side validation logic here before creating user
        const user = await UserDAL.createUser(userData);
        return {
            _id: user._id,
            firstName: user.firstName,
            lastName: user.lastName,
            email: user.email,
            role: user.role,
            token: generateToken(user._id),
        };
    } catch(error) {
        console.error('SERVICE: Error during user registration process:', error);
        throw error;
    }
};

const loginUser = async (email, password) => {
    // Add CAPTCHA server-side validation logic here
    const user = await UserDAL.findUserByEmail(email);
    if (user && (await user.matchPassword(password))) {
        return {
            _id: user._id,
            firstName: user.firstName,
            lastName: user.lastName,
            email: user.email,
            role: user.role,
            loyaltyPoints: user.loyaltyPoints,
            eligibleForDiscountedRides: user.eligibleForDiscountedRides,
            token: generateToken(user._id),
        };
    } else {
        const error = new Error('Invalid email or password');
        error.statusCode = 401;
        throw error;
    }
};

const createAdminAccount = async (adminData, creatorRole) => {
    if (creatorRole !== 'admin') {
        const error = new Error('Not authorized to create admin accounts');
        error.statusCode = 403;
        throw error;
    }
    adminData.role = 'admin'; // Ensure role is admin
    return await this.registerUser(adminData); // Reuse register logic
}

// --- Forgot/Reset Password (Simplified - requires email sending) ---
const forgotPassword = async (email) => {
    const user = await UserDAL.findUserByEmail(email);
    if (!user) {
        // Don't reveal if user exists for security, but for dev:
        const error = new Error('User not found');
        error.statusCode = 404;
        throw error;
    }

    const resetToken = crypto.randomBytes(20).toString('hex');
    user.resetPasswordToken = crypto.createHash('sha256').update(resetToken).digest('hex');
    user.resetPasswordExpires = Date.now() + 10 * 60 * 1000; // 10 minutes

    await UserDAL.updateUser(user._id, {
        resetPasswordToken: user.resetPasswordToken,
        resetPasswordExpires: user.resetPasswordExpires
    });

    // TODO: Send email with resetToken (not the hashed one)
    // const resetUrl = `http://localhost:3000/resetpassword/${resetToken}`; // Frontend URL
    // const message = `You are receiving this email because you (or someone else) has requested the reset of a password. Please make a PUT request to: \n\n ${resetUrl}`;
    // await sendEmail({ email: user.email, subject: 'Password Reset Token', message });

    return { message: 'Password reset token sent to email (if account exists). Implement email sending.' };
};

const resetPassword = async (resetToken, newPassword) => {
    const hashedToken = crypto.createHash('sha256').update(resetToken).digest('hex');
    const user = await User.findOne({ // Direct model usage for this specific query
        resetPasswordToken: hashedToken,
        resetPasswordExpires: { $gt: Date.now() }
    });

    if (!user) {
        const error = new Error('Invalid or expired token');
        error.statusCode = 400;
        throw error;
    }

    user.password = newPassword; // Mongoose pre-save hook will hash it
    user.resetPasswordToken = undefined;
    user.resetPasswordExpires = undefined;
    await user.save();

    return { message: 'Password reset successful' };
};

module.exports = {
    registerUser,
    loginUser,
    createAdminAccount,
    forgotPassword,
    resetPassword
}