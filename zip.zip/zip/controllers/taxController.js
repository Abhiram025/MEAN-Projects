// controllers/taxController.js (or your preferred filename)
const TaxService = require('../services/taxService'); // Or your service filename

const addTax = async (req, res, next) => {
    try {
        // Add any input validation for req.body here if needed
        const tax = await TaxService.addTaxRule(req.body);
        res.status(201).json(tax);
    } catch (error) {
        next(error); // Pass error to the global error handler
    }
};

const getAllTaxes = async (req, res, next) => {
    try {
        const taxes = await TaxService.getAllTaxRules();
        res.status(200).json(taxes);
    } catch (error) {
        next(error);
    }
};

const getTaxById = async (req, res, next) => {
    try {
        const tax = await TaxService.getTaxRuleById(req.params.id);
        res.status(200).json(tax);
    } catch (error) {
        next(error);
    }
};

const updateTax = async (req, res, next) => {
    try {
        // Add any input validation for req.body here if needed
        const tax = await TaxService.updateTaxRule(req.params.id, req.body);
        res.status(200).json(tax);
    } catch (error) {
        next(error);
    }
};

const deleteTax = async (req, res, next) => {
    try {
        const result = await TaxService.deleteTaxRule(req.params.id);
        res.status(200).json(result); // `result` is likely { message: 'Tax rule deleted successfully' }
    } catch (error) {
        next(error);
    }
};

// Export all controller functions
module.exports = {
    addTax,
    getAllTaxes,
    getTaxById,
    updateTax,
    deleteTax
};