// controllers/rentalController.js (or your preferred filename)
const RentalService = require('../services/rentalService'); // Or your service filename

// --- User Rental Controller Functions ---

const bookCar = async (req, res, next) => {
    try {
        const { carId, rentalStartDate, rentalEndDate } = req.body;
        if (!carId || !rentalStartDate || !rentalEndDate) {
            const error = new Error('Car ID, rental start date, and rental end date are required');
            error.statusCode = 400;
            return next(error);
        }
        const rental = await RentalService.bookCar(req.user._id, carId, rentalStartDate, rentalEndDate);
        res.status(201).json(rental);
    } catch (error) {
        next(error);
    }
};

const getMyRentals = async (req, res, next) => {
    try {
        const rentals = await RentalService.getUserRentals(req.user._id, 'future');
        res.status(200).json(rentals);
    } catch (error) {
        next(error);
    }
};

const getMyRentalHistory = async (req, res, next) => {
    try {
        const rentals = await RentalService.getUserRentals(req.user._id, 'previous');
        res.status(200).json(rentals);
    } catch (error) {
        next(error);
    }
};

const cancelBooking = async (req, res, next) => {
    try {
        const rental = await RentalService.cancelBooking(req.params.rentalId, req.user._id, req.user.role);
        res.status(200).json(rental);
    } catch (error) {
        next(error);
    }
};

// --- Admin Rental Controller Functions ---

const getAllRentalsAdmin = async (req, res, next) => {
    try {
        const rentals = await RentalService.getAllRentalsForAdmin();
        res.status(200).json(rentals);
    } catch (error) {
        next(error);
    }
};

const getUserRentalHistoryAdmin = async (req, res, next) => {
    try {
        const rentals = await RentalService.getRentalHistoryForUserByAdmin(req.params.userId);
        res.status(200).json(rentals);
    } catch (error) {
        next(error);
    }
};

const pickupCar = async (req, res, next) => { // Renamed to avoid conflict if 'pickupCar' was a typo
    try {
        const { pickupOdometerReading } = req.body;
        if (pickupOdometerReading === undefined) {
            const error = new Error('Pickup Odometer reading is required');
            error.statusCode = 400;
            return next(error);
        }
        // Assuming req.user._id for admin is the admin's ID performing the action
        const rental = await RentalService.pickupCar(req.params.rentalId, pickupOdometerReading, req.user._id);
        res.status(200).json(rental);
    } catch (error) {
        next(error);
    }
};

const returnCar = async (req, res, next) => { // Renamed to avoid conflict
    try {
        const { returnOdometerReading } = req.body;
        if (returnOdometerReading === undefined) {
            const error = new Error('Return Odometer reading is required');
            error.statusCode = 400;
            return next(error);
        }
        // Assuming req.user._id for admin is the admin's ID performing the action
        const rental = await RentalService.returnCar(req.params.rentalId, returnOdometerReading, req.user._id);
        res.status(200).json(rental);
    } catch (error) {
        next(error);
    }
};

// Export all controller functions
module.exports = {
    bookCar,
    getMyRentals,
    getMyRentalHistory,
    cancelBooking,
    getAllRentalsAdmin,
    getUserRentalHistoryAdmin,
    pickupCar, // Using the renamed function
    returnCar  // Using the renamed function
};