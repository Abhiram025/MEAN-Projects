const AuthService = require('../services/authService');
 // npm i express-async-handler

// @desc    Register a new user
// @route   POST /api/auth/register
// @access  Public
const registerUser = async (req, res) => {
    // Add input validation here (e.g. using Joi or express-validator)
    // For CAPTCHA, you'd verify the token from req.body.captchaToken with Google's API
    const user = await AuthService.registerUser(req.body);
    res.status(201).json(user);
};

// @desc    Authenticate user & get token
// @route   POST /api/auth/login
// @access  Public
const loginUser = async (req, res) => {
    const { email, password } = req.body;
    // Add CAPTCHA server-side validation here
    const user = await AuthService.loginUser(email, password);
    res.status(200).json(user);
};

// @desc    Logout user (client-side responsibility to clear token)
// @route   POST /api/auth/logout
// @access  Private
const logoutUser = async (req, res) => {
    // For session-based auth, you'd destroy session. For JWT, it's stateless.
    // Client should remove the token.
    res.status(200).json({ message: 'Logged out successfully' });
};

 // @desc    Create a new admin account
 // @route   POST /api/admin/auth/create-admin
 // @access  Private/Admin
 const createAdmin = async (req, res) => {
     const admin = await AuthService.createAdminAccount(req.body, req.user.role);
     res.status(201).json(admin);
 };

// @desc    Forgot password
// @route   POST /api/auth/forgot-password
// @access  Public
const forgotPassword = async (req, res) => {
    const { email } = req.body;
    const result = await AuthService.forgotPassword(email);
    res.status(200).json(result);
};

// @desc    Reset password
// @route   PUT /api/auth/reset-password/:token
// @access  Public
const resetPassword = async (req, res) => {
    const { token } = req.params;
    const { password } = req.body;
    const result = await AuthService.resetPassword(token, password);
    res.status(200).json(result);
};

module.exports={registerUser, loginUser, logoutUser, createAdmin, forgotPassword, resetPassword}