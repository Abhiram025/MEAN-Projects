// controllers/userController.js (or your preferred filename)
const UserService = require('../services/userService'); // Or your service filename

const getUserProfile = async (req, res, next) => {
    try {
        const user = await UserService.getUserProfile(req.user._id);
        res.status(200).json(user);
    } catch (error) {
        next(error); // Pass error to the global error handler
    }
};

const updateUserProfile = async (req, res, next) => {
    try {
        // Sanitize req.body, don't allow changing role or password here directly
        const { firstName, lastName, phoneNumber, address } = req.body;
        const updateData = { firstName, lastName, phoneNumber, address };

        // Remove undefined keys to prevent accidentally clearing fields with undefined
        Object.keys(updateData).forEach(key => {
            if (updateData[key] === undefined) {
                delete updateData[key];
            }
        });

        // Ensure at least one field is being updated (optional, but good practice)
        if (Object.keys(updateData).length === 0) {
            const error = new Error('No valid fields provided for update.');
            error.statusCode = 400;
            return next(error);
        }

        const user = await UserService.updateUserProfile(req.user._id, updateData);
        res.status(200).json(user);
    } catch (error) {
        next(error);
    }
};

const changePassword = async (req, res, next) => {
    try {
        const { oldPassword, newPassword } = req.body;
        if (!oldPassword || !newPassword) {
            const error = new Error('Old and new password are required');
            error.statusCode = 400;
            return next(error); // Use next(error) for synchronous validation errors too
        }
        const result = await UserService.changePassword(req.user._id, oldPassword, newPassword);
        res.status(200).json(result); // `result` is likely { message: 'Password changed successfully' }
    } catch (error) {
        next(error);
    }
};

// Export all controller functions
module.exports = {
    getUserProfile,
    updateUserProfile,
    changePassword
};