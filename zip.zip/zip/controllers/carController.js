const CarService = require('../services/carService');

// --- Admin Routes ---
// @desc    Add a new car
// @route   POST /api/admin/cars
// @access  Private/Admin
const addCar = async (req, res) => {
    // Add validation for req.body
    const car = await CarService.addCar(req.body);
    res.status(201).json(car);
};

// @desc    Get all cars (for admin)
// @route   GET /api/admin/cars
// @access  Private/Admin
const getAllCarsAdmin = async (req, res) => {
    const cars = await CarService.getAllCarsForAdmin(req.query); // Pass query for potential filters
    res.status(200).json(cars);
};

// @desc    Get car by ID (for admin)
// @route   GET /api/admin/cars/:id
// @access  Private/Admin
const getCarByIdAdmin = async (req, res) => {
    const car = await CarService.getCarById(req.params.id);
    res.status(200).json(car);
};

// @desc    Update car details
// @route   PUT /api/admin/cars/:id
// @access  Private/Admin
const updateCar = async (req, res) => {
    const car = await CarService.updateCarDetails(req.params.id, req.body);
    res.status(200).json(car);
};

// @desc    Delete a car
// @route   DELETE /api/admin/cars/:id
// @access  Private/Admin
const deleteCar = async (req, res) => {
    const result = await CarService.removeCar(req.params.id);
    res.status(200).json(result);
};


// --- User Routes ---
// @desc    Search/filter available cars
// @route   GET /api/cars/search
// @access  Public or Private (user)
const searchCars = async (req, res) => {
    // req.query will contain search params like type, make, model
    const cars = await CarService.searchAvailableCars(req.query);
    res.status(200).json(cars);
};

// @desc    View specific car details for booking
// @route   GET /api/cars/:id
// @access  Public or Private (user)
const getCarDetailsForUser = async (req, res) => {
    const car = await CarService.getCarById(req.params.id);
    // Could filter out admin-specific details if any before sending to user
    res.status(200).json(car);
};

module.exports = {addCar, getAllCarsAdmin, getCarByIdAdmin, updateCar, deleteCar, searchCars, getCarDetailsForUser}