const Tax = require('../models/TaxModel');

const createTax = async (taxData) => {
    const tax = new Tax(taxData);
    return await tax.save();
};

const findTaxById = async (id) => {
    return await Tax.findById(id);
};

const findTaxByCarTypeCategory = async (carTypeCategory) => {
    return await Tax.findOne({ carTypeCategory });
};

const findAllTaxes = async () => {
    return await Tax.find();
};

const updateTax = async (id, updateData) => {
    return await Tax.findByIdAndUpdate(id, { $set: updateData }, { new: true, runValidators: true });
};

const deleteTax = async (id) => {
    return await Tax.findByIdAndDelete(id);
};

module.exports = {
    createTax,
    findTaxById,
    findTaxByCarTypeCategory,
    findAllTaxes,
    updateTax,
    deleteTax
}