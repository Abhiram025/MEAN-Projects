const User = require('../models/UserModel');

const createUser = async (userData) => {
    try {
        const user = new User(userData);
        return await user.save();
    } catch(error) {
        console.error('DAL: Error saving user:', error); // THIS IS CRUCIAL
        throw error;
    }
};

const findUserByEmail = async (email) => {
    return await User.findOne({ email });
};

const findUserById = async (id) => {
    return await User.findById(id).select('-password'); // Exclude password
};

const updateUser = async (id, updateData) => {
    return await User.findByIdAndUpdate(id, { $set: updateData }, { new: true, runValidators: true }).select('-password');
};

const getAllUsersForAdmin = async () => { // For admin to view loyalty points etc.
    return await User.find().select('-password');
};

module.exports = {
    createUser,
    findUserByEmail,
    findUserById,
    updateUser,
    getAllUsersForAdmin
}
// Add other DAL functions as needed (e.g., for password reset tokens)