const Car = require('../models/CarModel');

const createCar = async (carData) => {
    const car = new Car(carData);
    return await car.save();
};

const findCarById = async (id) => {
    return await Car.findById(id);
};

const findAllCars = async (filters = {}) => {
    // Example: filter by type, availabilityStatus
    // For more complex search, enhance this
    return await Car.find(filters);
};

const updateCar = async (id, updateData) => {
    return await Car.findByIdAndUpdate(id, { $set: updateData }, { new: true, runValidators: true });
};

const deleteCar = async (id) => {
    return await Car.findByIdAndDelete(id);
};

module.exports = {
    createCar,
    findAllCars,
    updateCar,
    deleteCar
}