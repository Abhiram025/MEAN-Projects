const Rental = require('../models/RentalModel');

const createRental = async (rentalData) => {
    const rental = new Rental(rentalData);
    return await rental.save();
};

const findRentalById = async (id) => {
    return await Rental.findById(id).populate('userId', 'firstName lastName email').populate('carId');
};

const findRentalsByUserId = async (userId) => {
    return await Rental.find({ userId }).populate('carId').sort({ rentalStartDate: -1 });
};

const findAllRentals = async () => {
    return await Rental.find().populate('userId', 'firstName lastName email').populate('carId').sort({ createdAt: -1 });
};

const updateRental = async (id, updateData) => {
    return await Rental.findByIdAndUpdate(id, { $set: updateData }, { new: true, runValidators: true });
};

module.exports = {
    createRental,
    findRentalById,
    findRentalsByUserId,
    findAllRentals,
    updateRental
}