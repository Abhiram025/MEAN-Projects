const mongoose = require('mongoose');

const RentalSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    carId: { type: mongoose.Schema.Types.ObjectId, ref: 'Car', required: true },
    rentalStartDate: { type: Date, required: true }, // Planned start
    rentalEndDate: { type: Date, required: true },   // Planned end
    actualPickupDate: { type: Date },
    actualReturnDate: { type: Date },
    pickupOdometer: { type: Number },
    returnOdometer: { type: Number },
    totalKmDriven: { type: Number, default: 0 },
    baseCostPerKm: { type: Number, required: true },
    baseCostPerDay: { type: Number, required: true },
    taxRateApplied: { type: Number, required: true }, // e.g., 0.10, 0.20
    taxAmount: { type: Number, default: 0 },
    frequentRenterDiscountAmount: { type: Number, default: 0 },
    loyaltyDiscountAmount: { type: Number, default: 0 },
    totalCost: { type: Number, default: 0 },
    status: {
        type: String,
        enum: ['Booked', 'Rented', 'Completed', 'Cancelled'],
        default: 'Booked'
    },
    loyaltyPointsEarned: { type: Number, default: 0 },
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
});

RentalSchema.pre('save', function(next) {
    this.updatedAt = Date.now();
    next();
});

module.exports = mongoose.model('Rental', RentalSchema);