const mongoose = require('mongoose');

const TaxSchema = new mongoose.Schema({
    // Maps to Car.type categories broadly
    carTypeCategory: {
        type: String,
        enum: ['Basic', 'Mid-range', 'High-end/Luxury'], // These should group Car.type
        unique: true,
        required: true
    },
    taxPercentage: { type: Number, required: true, min: 0, max: 100 }, // Store as percentage e.g. 10 for 10%
    description: { type: String },
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
});

TaxSchema.pre('save', function(next) {
    this.updatedAt = Date.now();
    next();
});

module.exports = mongoose.model('Tax', TaxSchema);