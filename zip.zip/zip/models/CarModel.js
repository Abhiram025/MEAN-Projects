const mongoose = require('mongoose');

const CarSchema = new mongoose.Schema({
    make: { type: String, required: true },
    model: { type: String, required: true },
    year: { type: Number, required: true },
    type: {
        type: String,
        enum: ['SUV', 'Sedan', 'Compact', 'Mini-van', 'Luxury', 'Basic', 'Mid-range', 'High-end'],
        required: true
    },
    transmission: { type: String, enum: ['Automatic', 'Manual'], required: true },
    fuelType: { type: String, enum: ['Petrol', 'Diesel', 'Electric', 'Hybrid'], required: true },
    seats: { type: Number, required: true },
    pricePerKm: { type: Number, required: true },
    pricePerDay: { type: Number, required: true },
    availabilityStatus: {
        type: String,
        enum: ['Available', 'Rented', 'Maintenance'],
        default: 'Available'
    },
    currentOdometer: { type: Number, default: 0 },
    imageUrl: { type: String },
    registrationNumber: { type: String, unique: true, required: true },
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
});

CarSchema.pre('save', function(next) {
    this.updatedAt = Date.now();
    next();
});

module.exports = mongoose.model('Car', CarSchema);