const express = require('express');
const cors = require('cors');
const config = require('./config');
const connectDB = require('./config/db');
const { errorHandler, notFound } = require('./middleware/errorMiddleware');

// Import Routes
const authRoutes = require('./routes/authRoutes');
const userRoutes = require('./routes/userRoutes');
const carRoutes = require('./routes/carRoutes');
const taxRoutes = require('./routes/taxRoutes');
const rentalRoutes = require('./routes/rentalRoutes');

// Connect to Database
connectDB();

const app = express();

// Middleware
app.use(cors()); // Enable CORS for all routes
app.use(express.json()); // To parse JSON bodies
app.use(express.urlencoded({ extended: true })); // To parse URL-encoded bodies

// Mount Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes); // Handles /profile, /change-password
app.use('/api', carRoutes);       // Handles /admin/cars and /cars
app.use('/api', taxRoutes);       // Handles /admin/taxes
app.use('/api', rentalRoutes);    // Handles /rentals and /admin/rentals

// Welcome Route
app.get('/', (req, res) => {
    res.send('Carzy Car Rentals API is running...');
});

// Error Handling Middleware (should be last)
app.use(notFound); // For 404 errors
app.use(errorHandler); // For all other errors

const PORT = config.port;

app.listen(PORT, () => {
    console.log(`Server running in ${process.env.NODE_ENV || 'development'} mode on port ${PORT}`);
});