const UserService = require('../services/userService');

class UserController {
  async getProfile(req, res) {
    try {
      const user = await UserService.getUserById(req.user.id);
      res.json(user);
    } catch (error) {
      res.status(404).json({ message: error.message });
    }
  }

  async updateProfile(req, res) {
    try {
      const user = await UserService.updateProfile(req.user.id, req.body);
      res.json(user);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  async changePassword(req, res) {
    try {
      const { currentPassword, newPassword } = req.body;
      if (!currentPassword || !newPassword) {
        return res.status(400).json({ message: 'Both current and new password are required' });
      }
      await UserService.changePassword(req.user.id, currentPassword, newPassword);
      res.json({ message: 'Password changed successfully' });
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  async requestPasswordReset(req, res) {
    try {
      const { email } = req.body;
      if (!email) {
        return res.status(400).json({ message: 'Email is required' });
      }
      const resetToken=await UserService.requestPasswordReset(email);

      res.json({
        status:'success',
        message:'Token sent to email',
        token: resetToken//remove this in production
      })
      
    } catch (error) {
      res.status(500).json({status:'error', message: error.message });
    }
  }

  async resetPasswordToken(req, res) {
    try {
      const {token}=req.params;
      const {newPassword, confirmPassword}=req.body;

      if(!token) return res.status(400).json({status:'error', message: 'token required'})

      await UserService.resetPasswordWithToken(token, newPassword, confirmPassword);
      res.json({status:'success', message:'Password updated successfully'})
    }
    catch(err) {
      const statusCode=err.message.includes('token')?400:500;
      res.status(statusCode).json({status:'error',message:err.message})
    }
  }
}

module.exports = new UserController();