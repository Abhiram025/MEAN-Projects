const RentalService = require('../services/rentalService');

class RentalController {
  async bookCar(req, res) {
    try {
      const { carId, rentalStartDate, rentalEndDate } = req.body;
      const rental = await RentalService.bookCar(
        req.user.id, 
        carId, 
        new Date(rentalStartDate), 
        new Date(rentalEndDate)
      );
      res.status(201).json(rental);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  async pickupCar(req, res) {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Forbidden' });
      }
      const rental = await RentalService.pickupCar(
        req.params.id, 
        req.body.pickupOdometerReading
      );
      res.json(rental);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  async returnCar(req, res) {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Forbidden' });
      }
      const rental = await RentalService.returnCar(
        req.params.id, 
        req.body.returnOdometerReading
      );
      res.json(rental);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  async cancelBooking(req, res) {
    try {
      await RentalService.cancelBooking(
        req.params.id, 
        req.user.id, 
        req.user.role === 'admin'
      );
      res.json({ message: 'Booking cancelled successfully' });
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  async getUserRentals(req, res) {
    try {
      const rentals = await RentalService.getUserRentals(req.user.id, req.query.type);
      res.json(rentals);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  async getAllRentals(req, res) {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Forbidden' });
      }
      const rentals = await RentalService.getAllRentals();
      res.json(rentals);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }

  async getUserRentalHistory(req, res) {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Forbidden' });
      }
      const rentals = await RentalService.getUserRentals(req.params.userId);
      res.json(rentals);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  }
}

module.exports = new RentalController();