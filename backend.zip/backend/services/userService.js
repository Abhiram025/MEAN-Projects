const UserDAL = require('../dal/userDal');

class UserService {
  async updateProfile(userId, profileData) {
    return await UserDAL.updateById(userId, profileData);
  }

  async changePassword(userId, currentPassword, newPassword) {
    const user = await UserDAL.findById(userId);
    const isMatch = await user.comparePassword(currentPassword);
    if (!isMatch) {
      throw new Error('Current password is incorrect');
    }

    if (newPassword.length < 11) {
      throw new Error('Password must be at least 11 characters');
    }

    // Hash and save new password
    user.password = newPassword;
    await user.save(); // This triggers the pre-save hook
    
    return user;
  }

  async getUserById(userId) {
    return await UserDAL.findById(userId);
  }
}

module.exports = new UserService();