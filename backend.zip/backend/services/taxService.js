const TaxDAL = require('../dal/taxDal');

class TaxService {
  // ... keep existing methods ...

  async createTaxRule(taxData) {
    // Automatically set taxCategory based on carType
    taxData.taxCategory = this.getCarTypeTaxCategory(taxData.cartype);
    return await TaxDAL.create(taxData);
  }

  async updateTaxRule(cartype, updateData) {
    // If carType is being updated, update taxCategory too
    if (updateData.cartype && updateData.cartype !== cartype) {
      const exists = await TaxDAL.findOne({ cartype: updateData.cartype });
      if (exists) throw new Error('Car type already exists');
    }
    return await TaxDAL.findOneAndUpdate(
      { cartype }, 
      {$set: updateData}, 
      { new: true }
    );
  }

  // Modified to use findOne instead of findByCarType
  async getTaxByCarType(cartype) {
    const taxRule = await TaxDAL.findOne({ cartype });
    if (!taxRule) {
      throw new Error(`Tax rule not found for car type: ${cartype}`);
    }
    return taxRule;
  }

  async getAllTaxRules() {
    try {
      return await TaxDAL.find({});
    } catch (error) {
      throw new Error('Failed to fetch tax rules: ' + error.message);
    }
  }

  // Keep your existing getCarTypeTaxCategory method
  getCarTypeTaxCategory(cartype) {
    const taxCategories = {
      sedan: 'economy',
      suv: 'premier',
      hyundai: 'economy',
      honda: 'premier',
      force: 'luxury'
    };
    return taxCategories[cartype] || 'economy';
  }
}

module.exports = new TaxService();