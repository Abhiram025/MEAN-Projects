const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const validate  = require('../middleware/validation');
const { check } = require('express-validator');

router.post('/register', 
  validate([
    check('username').notEmpty().withMessage('Username is required'),
    check('firstname').notEmpty().withMessage('firstname is required'),
    check('lastname').notEmpty().withMessage('lastname is required'),
    check('address').notEmpty().withMessage('address is required'),
    check('email').isEmail().withMessage('Valid email is required'),
    check('password').isLength({ min: 11 }).withMessage('Password must be at least 11 characters')    
  ]),
  authController.register
);

router.post('/login', 
  validate([
    check('username').notEmpty().withMessage('Username is required'),
    check('password').notEmpty().withMessage('Password is required')
  ]),
  authController.login
);

module.exports = router;