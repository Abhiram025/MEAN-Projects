const express = require('express');
const router = express.Router();
const taxController = require('../controllers/taxController');
const { authenticate, authorizeAdmin } = require('../middleware/auth');

router.use(authenticate, authorizeAdmin);

router.get('/', taxController.getAllTaxRules);
router.get('/:cartype', taxController.getTaxByCarType);


router.post('/', taxController.createTaxRule);
router.put('/:cartype', taxController.updateTaxRule);

module.exports = router;