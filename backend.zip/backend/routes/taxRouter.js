const express = require('express');
const router = express.Router();
const taxController = require('../controllers/taxController');
const { authenticate, authorizeAdmin } = require('../middleware/auth');

router.use(authenticate, authorizeAdmin);

router.post('/', taxController.createTaxRule);
router.get('/', taxController.getAllTaxRules);
router.get('/:carType', taxController.getTaxByCarType);
router.put('/:carType', taxController.updateTaxRule);

module.exports = router;