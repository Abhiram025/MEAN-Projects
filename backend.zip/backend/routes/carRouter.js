const express = require('express');
const router = express.Router();
const carController = require('../controllers/carController');
const { authenticate } = require('../middleware/auth');


// Public routes
router.get('/', carController.getAvailableCars);
router.get('/:id', carController.getCarById);
router.get('/type/:cartype', carController.getCarsByType);

// Admin-only routes
router.use(authenticate);
router.post('/', carController.createCar);
router.put('/:id',carController.updateCar);
router.delete('/:id', carController.deleteCar);

module.exports = router;