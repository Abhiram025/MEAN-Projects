require('dotenv').config();
const mongoose = require('mongoose');
const Tax = require('../models/taxModel');
const User = require('../models/userModel');
const bcrypt = require('bcryptjs');
const config = require('../config');

async function initialize() {
  try {
    await mongoose.connect(config.MONGODB_URI);

    // Create default tax rules
    const taxRules = [
      { cartype: 'sedan', taxPercentage: 10, taxCategory: 'economy' },
      { cartype: 'suv', taxPercentage: 15, taxCategory: 'premier' },
      { cartype: 'hyundai', taxPercentage: 12, taxCategory: 'economy' },
      { cartype: 'honda', taxPercentage: 18, taxCategory: 'premier' },
      { cartype: 'force', taxPercentage: 25, taxCategory: 'luxury' }
    ];

    for (const rule of taxRules) {
      await Tax.findOneAndUpdate(
        { cartype: rule.cartype },
        rule,
        { upsert: true, new: true }
      );
    }
    console.log('Tax rules initialized');
    process.exit(0);
  } catch (error) {
    console.error('Initialization failed:', error);
    process.exit(1);
  }
}

initialize();