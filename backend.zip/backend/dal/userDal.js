const BaseDAL = require('./baseDal');
const User = require('../models/userModel');

class UserDAL extends BaseDAL {
  constructor() {
    super(User);
  }

  async findByEmail(email) {
    return await this.findOne({email});
  }
}

module.exports = new UserDAL();