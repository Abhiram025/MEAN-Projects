const mongoose = require('mongoose');

const rentalSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  car: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Car', required: true,
    validate: {
    validator: async function(v) {
      const car = await mongoose.model('Car').findById(v);
      return car !== null;
    },
    message: props => `Car ${props.value} does not exist`
  } 
  },
  rentalStartDate: { type: Date, required: true },
  rentalEndDate: { type: Date, required: true },
  actualPickupDate: Date,
  actualReturnDate: Date,
  pickupOdometer: Number,
  returnOdometer: Number,
  totalKmDriven: Number,
  baseCostPerKm: Number,
  baseCostPerDay: Number,
  taxRateApplied: Number,
  taxAmount: Number,
  frequentRenterDiscountAmount: Number,
  loyaltyDiscountAmount: Number,
  totalCost: Number,
  status: { 
    type: String, 
    enum: ['booked', 'rented', 'completed', 'cancelled'], 
    default: 'booked' 
  },
  loyaltyPointsEarned: { type: Number, default: 0 }
}, { timestamps: true });

module.exports = mongoose.model('Rental', rentalSchema);